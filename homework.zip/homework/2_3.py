a = int(input('请输入整数a:'))
b = int(input('请输入整数b:'))
c = int(input('请输入整数c:'))

b, c, a = a, b, c
print(f'a = {a}, b = {b}, c = {c}')